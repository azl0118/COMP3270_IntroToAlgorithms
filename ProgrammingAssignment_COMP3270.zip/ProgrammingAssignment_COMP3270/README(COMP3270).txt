Name: Adam Lee

Files:
- ProgrammingAssignment_COMP3270.ipynb
- README.txt
- ProgrammingAssignment_Analysis(COMP3270).pdf

Environment:
Python 3 using Jupyter Notebook

How to Run: 
Open terminal, enter jupyter notebook, press enter this will run jupyter notebook, locate file called "ProgrammingAssignment_COMP3270". Once in file, locate the Run tab and scroll down to "Restart Kernel and Run All Cells", this will start the program and run. 

NOTE: The program has a average time of ~340 seconds to finish.


Certification:
“I certify that I wrote the code I am submitting. I did not copy the whole or parts of it from another student or have another person write the code for me. Any code I am reusing or generated with Artificial Intelligence aid in my program is marked as such with its source identified in comments."

AI Acknowledgment:
The author would like to acknowledge the use of ChatGPT, a language model developed by OpenAI, in the preparation of this assignment. It was used for debugging, explanation, and structuring assistance. It was used to understand how to use jupyter, maxtrix operations, and cell for input read file.